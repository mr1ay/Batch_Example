# batch-code
Batch code to automate and schedule functions

For windows automated task including renaming, moving, scheduling ,mapping drives and parsing arguments to exe's.
